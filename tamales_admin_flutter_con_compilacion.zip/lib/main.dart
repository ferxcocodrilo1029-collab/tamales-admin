import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

final money = NumberFormat.currency(locale: 'es_MX', symbol: '\$');
final dateFmt = DateFormat('dd/MM/yyyy HH:mm');

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = Store();
  await store.init();
  runApp(ChangeNotifierProvider.value(value: store, child: const TamalesApp()));
}

class TamalesApp extends StatelessWidget {
  const TamalesApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Tamales Admin',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff087f6e)), useMaterial3: true),
    darkTheme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff48c9a8), brightness: Brightness.dark), useMaterial3: true),
    themeMode: ThemeMode.system,
    home: const HomePage(),
  );
}

class Tamal {
  int? id; String name, description, icon; double price; int stock;
  Tamal({this.id, required this.name, required this.description, required this.icon, required this.price, required this.stock});
  factory Tamal.from(Map<String,Object?> m) => Tamal(id:m['id'] as int, name:m['name'] as String, description:m['description'] as String, icon:m['icon'] as String, price:(m['price'] as num).toDouble(), stock:m['stock'] as int);
  Map<String,Object?> toMap() => {'name':name,'description':description,'icon':icon,'price':price,'stock':stock};
}
class Customer {
  int? id; String name, phone, avatar;
  Customer({this.id,required this.name,required this.phone,required this.avatar});
  factory Customer.from(Map<String,Object?> m)=>Customer(id:m['id'] as int,name:m['name'] as String,phone:m['phone'] as String,avatar:m['avatar'] as String);
  Map<String,Object?> toMap()=>{'name':name,'phone':phone,'avatar':avatar};
}
class OrderLine {
  int tamalId, quantity; String tamalName; double price;
  OrderLine({required this.tamalId,required this.quantity,required this.tamalName,required this.price});
  double get total=>price*quantity;
  Map<String,Object?> toMap()=>{'tamalId':tamalId,'quantity':quantity,'tamalName':tamalName,'price':price};
}
class OrderRecord {
  int? id; int customerId; String customerName, createdAt; List<OrderLine> lines; bool delivered, paid, closed;
  OrderRecord({this.id,required this.customerId,required this.customerName,required this.createdAt,required this.lines, this.delivered=false,this.paid=false,this.closed=false});
  double get total=>lines.fold(0,(s,l)=>s+l.total);
  int get units=>lines.fold(0,(s,l)=>s+l.quantity);
}
class Store extends ChangeNotifier {
  late Database db;
  List<Tamal> tamales=[]; List<Customer> customers=[]; List<OrderRecord> orders=[];
  Future<void> init() async {
    db=await openDatabase(p.join(await getDatabasesPath(),'tamales_admin.db'),version:1,onCreate:(d,v) async {
      await d.execute('CREATE TABLE tamales(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,description TEXT,icon TEXT,price REAL,stock INTEGER)');
      await d.execute('CREATE TABLE customers(id INTEGER PRIMARY KEY AUTOINCREMENT,name TEXT,phone TEXT,avatar TEXT)');
      await d.execute('CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT,customerId INTEGER,customerName TEXT,createdAt TEXT,lines TEXT,delivered INTEGER,paid INTEGER,closed INTEGER,total REAL,units INTEGER)');
    });
    if ((await db.query('tamales')).isEmpty) {
      for(final t in [
        Tamal(name:'Verde',description:'Pollo en salsa verde',icon:'🌿',price:18,stock:50),
        Tamal(name:'Mole',description:'Pollo con mole tradicional',icon:'🍫',price:20,stock:45),
        Tamal(name:'Rajas',description:'Rajas con queso',icon:'🌶️',price:18,stock:35),
        Tamal(name:'Dulce',description:'Tamal dulce de color',icon:'🍓',price:16,stock:30),
        Tamal(name:'Puerco',description:'Carne de cerdo en salsa roja',icon:'🥘',price:20,stock:40),
      ]) { await db.insert('tamales',t.toMap()); }
    }
    await refresh();
  }
  Future<void> refresh() async {
    tamales=(await db.query('tamales',orderBy:'name')).map(Tamal.from).toList();
    customers=(await db.query('customers',orderBy:'name')).map(Customer.from).toList();
    final rows=await db.query('orders',orderBy:'id DESC');
    orders=rows.map((m) {
      final raw=(m['lines'] as String).split('|').where((s)=>s.isNotEmpty).map((s){
        final a=s.split('~'); return OrderLine(tamalId:int.parse(a[0]),quantity:int.parse(a[1]),tamalName:a[2],price:double.parse(a[3]));
      }).toList();
      return OrderRecord(id:m['id'] as int,customerId:m['customerId'] as int,customerName:m['customerName'] as String,createdAt:m['createdAt'] as String,lines:raw,delivered:(m['delivered'] as int)==1,paid:(m['paid'] as int)==1,closed:(m['closed'] as int)==1);
    }).toList();
    notifyListeners();
  }
  Future<void> saveTamal(Tamal t) async { if(t.id==null) await db.insert('tamales',t.toMap()); else await db.update('tamales',t.toMap(),where:'id=?',whereArgs:[t.id]); await refresh(); }
  Future<void> saveCustomer(Customer c) async { if(c.id==null) await db.insert('customers',c.toMap()); else await db.update('customers',c.toMap(),where:'id=?',whereArgs:[c.id]); await refresh(); }
  Future<void> addOrder(int customerId,List<OrderLine> lines) async {
    final customer=customers.firstWhere((c)=>c.id==customerId);
    for(final l in lines) {
      final t=tamales.firstWhere((t)=>t.id==l.tamalId);
      if(l.quantity>t.stock) throw Exception('No hay suficiente stock de ${t.name}.');
    }
    await db.transaction((txn) async {
      for(final l in lines) await txn.rawUpdate('UPDATE tamales SET stock=stock-? WHERE id=?',[l.quantity,l.tamalId]);
      final encoded=lines.map((l)=>'${l.tamalId}~${l.quantity}~${l.tamalName}~${l.price}').join('|');
      await txn.insert('orders',{'customerId':customer.id,'customerName':customer.name,'createdAt':DateTime.now().toIso8601String(),'lines':encoded,'delivered':0,'paid':0,'closed':0,'total':lines.fold<double>(0,(s,l)=>s+l.total),'units':lines.fold<int>(0,(s,l)=>s+l.quantity)});
    });
    await refresh();
  }
  Future<void> setOrderStatus(OrderRecord o,{bool? delivered,bool? paid}) async {
    await db.update('orders',{'delivered':(delivered??o.delivered)?1:0,'paid':(paid??o.paid)?1:0},where:'id=?',whereArgs:[o.id]); await refresh();
  }
  Future<void> closeDay() async {
    final ids=orders.where((o)=>!o.closed).map((o)=>o.id).toList();
    if(ids.isEmpty)return;
    final batch=db.batch();
    for(final id in ids) batch.update('orders',{'closed':1},where:'id=?',whereArgs:[id]);
    await batch.commit(); await refresh();
  }
  List<OrderRecord> get todayOrders => orders.where((o)=>DateTime.tryParse(o.createdAt)?.day==DateTime.now().day && DateTime.tryParse(o.createdAt)?.month==DateTime.now().month && DateTime.tryParse(o.createdAt)?.year==DateTime.now().year).toList();
  double get todaySales=>todayOrders.fold(0,(s,o)=>s+o.total);
  int get todayUnits=>todayOrders.fold(0,(s,o)=>s+o.units);
  int get unpaid=>todayOrders.where((o)=>!o.paid).length;
}

class HomePage extends StatefulWidget { const HomePage({super.key}); @override State<HomePage> createState()=>_HomePageState(); }
class _HomePageState extends State<HomePage> {
  int tab=0;
  @override Widget build(BuildContext context) {
    final store=context.watch<Store>();
    final pages=[Dashboard(store:store),InventoryPage(store:store),CustomersPage(store:store),OrdersPage(store:store),ClosePage(store:store)];
    return Scaffold(
      appBar:AppBar(title:const Text('🌽 Tamales Admin'),centerTitle:false),
      body:pages[tab],
      bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [
        NavigationDestination(icon:Icon(Icons.dashboard_outlined),label:'Inicio'),
        NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'Almacén'),
        NavigationDestination(icon:Icon(Icons.people_outline),label:'Clientes'),
        NavigationDestination(icon:Icon(Icons.receipt_long),label:'Pedidos'),
        NavigationDestination(icon:Icon(Icons.point_of_sale),label:'Cierre'),
      ]),
    );
  }
}
class Dashboard extends StatelessWidget {
 final Store store; const Dashboard({super.key,required this.store});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
   Text('Resumen de hoy',style:Theme.of(context).textTheme.headlineSmall),
   const SizedBox(height:12),
   Row(children:[Expanded(child:Metric(title:'Ventas',value:money.format(store.todaySales),icon:Icons.payments)),const SizedBox(width:10),Expanded(child:Metric(title:'Tamales vendidos',value:'${store.todayUnits}',icon:Icons.restaurant))]),
   const SizedBox(height:10),
   Row(children:[Expanded(child:Metric(title:'Pedidos',value:'${store.todayOrders.length}',icon:Icons.receipt)),const SizedBox(width:10),Expanded(child:Metric(title:'Pagos pendientes',value:'${store.unpaid}',icon:Icons.pending_actions))]),
   const SizedBox(height:20),Text('Inventario bajo',style:Theme.of(context).textTheme.titleLarge),
   ...store.tamales.where((t)=>t.stock<=10).map((t)=>ListTile(leading:Text(t.icon,style:const TextStyle(fontSize:26)),title:Text(t.name),trailing:Text('${t.stock} restantes'))),
   if(store.tamales.every((t)=>t.stock>10)) const ListTile(leading:Icon(Icons.check_circle,color:Colors.green),title:Text('No hay alertas de stock bajo')),
 ]);
}
class Metric extends StatelessWidget { final String title,value; final IconData icon; const Metric({super.key,required this.title,required this.value,required this.icon});
 @override Widget build(BuildContext context)=>Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:Theme.of(context).colorScheme.primary),const SizedBox(height:8),Text(title),Text(value,style:Theme.of(context).textTheme.titleLarge)]))); }

class InventoryPage extends StatelessWidget {
 final Store store; const InventoryPage({super.key,required this.store});
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.transparent,floatingActionButton:FloatingActionButton(onPressed:()=>showTamalForm(context,store),child:const Icon(Icons.add)),body:ListView(children:store.tamales.map((t)=>Card(child:ListTile(leading:Text(t.icon,style:const TextStyle(fontSize:30)),title:Text(t.name),subtitle:Text('${t.description}\\n${money.format(t.price)} · Stock: ${t.stock}'),isThreeLine:true,trailing:IconButton(icon:const Icon(Icons.edit),onPressed:()=>showTamalForm(context,store,t))))).toList()));
}
Future<void> showTamalForm(BuildContext context,Store store,[Tamal? item]) async {
 final name=TextEditingController(text:item?.name??''),desc=TextEditingController(text:item?.description??''),icon=TextEditingController(text:item?.icon??'🌽'),price=TextEditingController(text:item?.price.toString()??''),stock=TextEditingController(text:item?.stock.toString()??'');
 await showDialog(context:context,builder:(ctx)=>AlertDialog(title:Text(item==null?'Nuevo tamal':'Editar tamal'),content:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[field(name,'Nombre'),field(desc,'Descripción'),field(icon,'Ícono o emoji'),field(price,'Precio',numeric:true),field(stock,'Existencia',numeric:true)])),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty)return;await store.saveTamal(Tamal(id:item?.id,name:name.text.trim(),description:desc.text,icon:icon.text,price:double.tryParse(price.text)??0,stock:int.tryParse(stock.text)??0));if(ctx.mounted)Navigator.pop(ctx);},child:const Text('Guardar'))]));
}
Widget field(TextEditingController c,String label,{bool numeric=false})=>Padding(padding:const EdgeInsets.only(bottom:8),child:TextField(controller:c,keyboardType:numeric?const TextInputType.numberWithOptions(decimal:true):TextInputType.text,decoration:InputDecoration(labelText:label,border:const OutlineInputBorder())));

class CustomersPage extends StatelessWidget {
 final Store store; const CustomersPage({super.key,required this.store});
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.transparent,floatingActionButton:FloatingActionButton(onPressed:()=>showCustomerForm(context,store),child:const Icon(Icons.person_add)),body:ListView(children:store.customers.map((c)=>Card(child:ListTile(leading:avatarWidget(c.avatar),title:Text(c.name),subtitle:Text(c.phone.isEmpty?'Sin teléfono':c.phone),trailing:IconButton(icon:const Icon(Icons.edit),onPressed:()=>showCustomerForm(context,store,c))))).toList()));
}
Widget avatarWidget(String path)=>CircleAvatar(backgroundImage:path.startsWith('http')?NetworkImage(path):path.isNotEmpty&&File(path).existsSync()?FileImage(File(path)):null,child:path.isEmpty?const Icon(Icons.person):null);
Future<void> showCustomerForm(BuildContext context,Store store,[Customer? item]) async {
 final name=TextEditingController(text:item?.name??''),phone=TextEditingController(text:item?.phone??'');String avatar=item?.avatar??'';
 await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setState)=>AlertDialog(title:Text(item==null?'Añadir cliente custom':'Editar cliente'),content:Column(mainAxisSize:MainAxisSize.min,children:[avatarWidget(avatar),const SizedBox(height:10),Wrap(spacing:8,children:['👤','🧑','👩','👨','🧒','🌽'].map((a)=>ActionChip(label:Text(a),onPressed:()=>setState(()=>avatar=a))).toList()),OutlinedButton.icon(onPressed:()async{final x=await ImagePicker().pickImage(source:ImageSource.gallery,imageQuality:75);if(x!=null)setState(()=>avatar=x.path);},icon:const Icon(Icons.photo_library),label:const Text('Elegir de galería')),field(name,'Nombre'),field(phone,'Teléfono')]),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:()async{if(name.text.trim().isEmpty)return;await store.saveCustomer(Customer(id:item?.id,name:name.text.trim(),phone:phone.text,avatar:avatar));if(ctx.mounted)Navigator.pop(ctx);},child:const Text('Guardar'))])));
}

class OrdersPage extends StatelessWidget {
 final Store store; const OrdersPage({super.key,required this.store});
 @override Widget build(BuildContext context)=>Scaffold(backgroundColor:Colors.transparent,floatingActionButton:FloatingActionButton.extended(onPressed:()=>showOrderForm(context,store),icon:const Icon(Icons.add),label:const Text('Pedido')),body:ListView(children:store.orders.map((o)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
   Row(children:[Expanded(child:Text('${o.customerName} · ${money.format(o.total)}',style:Theme.of(context).textTheme.titleMedium)),Text(dateFmt.format(DateTime.parse(o.createdAt)))]),
   Text(o.lines.map((l)=>'${l.quantity} × ${l.tamalName}').join(', ')),
   Row(children:[Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,title:const Text('Entregado'),value:o.delivered,onChanged:(v)=>store.setOrderStatus(o,delivered:v))),Expanded(child:CheckboxListTile(contentPadding:EdgeInsets.zero,title:const Text('Pagado'),value:o.paid,onChanged:(v)=>store.setOrderStatus(o,paid:v)))]),
   if(o.closed)const Align(alignment:Alignment.centerRight,child:Chip(label:Text('Día cerrado')))
 ])))).toList()));
}
Future<void> showOrderForm(BuildContext context,Store store) async {
 if(store.customers.isEmpty){ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Primero registra un cliente.')));return;}
 int customer=store.customers.first.id!;final qty={for(final t in store.tamales)t.id!:0};
 await showDialog(context:context,builder:(ctx)=>StatefulBuilder(builder:(ctx,setState)=>AlertDialog(title:const Text('Crear pedido'),content:SizedBox(width:420,child:SingleChildScrollView(child:Column(mainAxisSize:MainAxisSize.min,children:[
 DropdownButtonFormField<int>(value:customer,decoration:const InputDecoration(labelText:'Cliente'),items:store.customers.map((c)=>DropdownMenuItem(value:c.id,child:Text(c.name))).toList(),onChanged:(v)=>setState(()=>customer=v!)),
 const SizedBox(height:8),...store.tamales.map((t)=>Row(children:[Expanded(child:Text('${t.icon} ${t.name} (${t.stock})')),IconButton(onPressed:()=>setState(()=>qty[t.id!] = (qty[t.id!]! - 1).clamp(0,999)),icon:const Icon(Icons.remove_circle_outline)),Text('${qty[t.id!]}'),IconButton(onPressed:()=>setState(()=>qty[t.id!] = (qty[t.id!]!+1).clamp(0,t.stock)),icon:const Icon(Icons.add_circle_outline))])),
 Text('Total: ${money.format(store.tamales.fold<double>(0,(s,t)=>s+qty[t.id!]!*t.price))}',style:Theme.of(context).textTheme.titleLarge)
 ]))),actions:[TextButton(onPressed:()=>Navigator.pop(ctx),child:const Text('Cancelar')),FilledButton(onPressed:()async{final lines=store.tamales.where((t)=>qty[t.id!]>0).map((t)=>OrderLine(tamalId:t.id!,quantity:qty[t.id!]!,tamalName:t.name,price:t.price)).toList();if(lines.isEmpty)return;try{await store.addOrder(customer,lines);if(ctx.mounted)Navigator.pop(ctx);}catch(e){ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(e.toString())));}},child:const Text('Guardar pedido'))])));
}

class ClosePage extends StatelessWidget {
 final Store store; const ClosePage({super.key,required this.store});
 @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[
   Text('Cierre de caja',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),
   Metric(title:'Total vendido hoy',value:money.format(store.todaySales),icon:Icons.payments),
   Metric(title:'Unidades vendidas',value:'${store.todayUnits}',icon:Icons.restaurant),
   Metric(title:'Pedidos del día',value:'${store.todayOrders.length}',icon:Icons.receipt),
   Metric(title:'Pedidos sin pago',value:'${store.todayOrders.where((o)=>!o.paid).length}',icon:Icons.money_off),
   const SizedBox(height:16),
   FilledButton.icon(onPressed:store.todayOrders.where((o)=>!o.closed).isEmpty?null:()async{final ok=await showDialog<bool>(context:context,builder:(ctx)=>AlertDialog(title:const Text('¿Finalizar el día?'),content:Text('Se cerrarán ${store.todayOrders.where((o)=>!o.closed).length} pedidos. Total de ventas: ${money.format(store.todaySales)}.'),actions:[TextButton(onPressed:()=>Navigator.pop(ctx,false),child:const Text('Cancelar')),FilledButton(onPressed:()=>Navigator.pop(ctx,true),child:const Text('Finalizar'))]));if(ok==true){await store.closeDay();if(context.mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Día finalizado.')));}},icon:const Icon(Icons.lock),label:const Text('Finalizar Día')),
   const SizedBox(height:8),const Text('El cierre marca los pedidos como cerrados. Los estados de entrega y pago se mantienen independientes.')
 ]);
}
