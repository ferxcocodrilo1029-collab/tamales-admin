# Tamales Admin (Flutter)

## Funciones incluidas
- Dashboard diario con ventas, unidades, pedidos y pagos pendientes.
- CRUD sencillo de inventario con precio y stock.
- Clientes manuales con avatar emoji o imagen de galería.
- Creación de pedidos desde clientes e inventario, descontando stock en una transacción SQLite.
- Estados independientes de Entregado y Pagado.
- Cierre diario con resumen y marca de pedidos cerrados.
- Tema claro/oscuro según sistema.

## Ejecutar
1. Instala Flutter SDK y configura Android Studio/Xcode.
2. Descomprime el proyecto.
3. Ejecuta:
   ```bash
   flutter pub get
   flutter run
   ```

## Notas
- La base local se guarda en SQLite en el dispositivo.
- La aplicación es una base funcional para prototipo/MVP. Antes de uso comercial, agrega autenticación, respaldo, manejo de devoluciones/anulaciones, validación robusta, reportes exportables y pruebas.
- Para la galería, `image_picker` requiere permisos/configuración nativa según plataforma. En Android recientes, la selección de imágenes usa el picker del sistema.
- `sqflite` soporta Android/iOS; para Web/Desktop se requiere adaptar la persistencia.
